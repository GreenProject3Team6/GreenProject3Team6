2024, 그린컴퓨터 의정부
(기업수요)Open API를 활용한 자바(JAVA)기반 풀스택개발자 양성과정

코드로 배우는 스프링 부트 웹 프로젝트
구명가게 코딩단 지음 / 남가람북스
Part 2.
프로젝트명 : 'guestbook'

(2024-07-16) 교재 139 page - build.gradle
https://cafe.naver.com/gugucoding/8692
